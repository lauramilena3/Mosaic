const int BITS_PER_INT = 32;
const int CONTIG_MAP_BIN_SIZE = 1024;
const int CHUNK_LENGTH = 1;//TODO?
const int MAX_GFF_LINE = 1023;
const int MAX_GFF_FEATURE_LENGTH = 128;
const int HASH_TABLE_SIZE = 17909;
const int FASTA_BLOCK = 60;
const int DEFAULT_MAX_FAM = 16;
